import java.util.Arrays;


/**
* This class represents an ordered list of cars.
* 
* CSC 1351 Programming Project No 1
* Section <002>
* 
* @author <Olivia Womble>
* @since <05.17.2024>
*/
public class aOrderedList<Car> {
	private int numObjects; //number of objects in the list
	final int SIZEINCREMENTS=20; //Size increments to resize list
	private Car [] oList; // Array for car list
	private int listSize; //Size of the list
	private int e;
	
	
	/**
	* <Method makes a new ordered list to resize the list>
	* 
	* CSC 1351 Programming Project No 1
	* Section <002>
	* 
	* @author <Olivia Womble>
	* @since <05.17.2024>
	*/
	
	public aOrderedList() {
		numObjects = 0;
		listSize = SIZEINCREMENTS;
		oList = (Car[]) new Object [SIZEINCREMENTS];
		
		/**
		* <Method adds a new car to the ordered list>
		* 
		* CSC 1351 Programming Project No 1
		* Section <002>
		* 
		* @author <Olivia Womble>
		* @since <05.17.2024>
		*/
}
	public void add (Car newCar) {
		if (numObjects == listSize) {
			listSize += 2;
			oList = Arrays.copyOf(oList, listSize); 
		}
	    oList[numObjects++] = newCar; // Add the newCar to the end of the list
	    Arrays.sort(oList, 0, numObjects);
		}
	
	
	/**
	* <Method returns the Car variable in the form of a string>
	* 
	* CSC 1351 Programming Project No 1
	* Section <002>
	* 
	* @author <Olivia Womble>
	* @since <05.17.2024>
	*/
	public String toString() {
	    String Bracket = "[";
	    for (int i = 0; i < numObjects; i++) {
	        if (i > 0) {
	            Bracket += ", ";
	        }
	        Bracket += oList[i].toString();
	    }
	    Bracket += "]";
	    return Bracket;
	}

	/**
	* <Method returns the number of cars in the list>
	* 
	* CSC 1351 Programming Project No 1
	* Section <002>
	* 
	* @author <Olivia Womble>
	* @since <05.17.2024>
	*/
	 public int size() {
	        return numObjects; // Return the number of elements in the list
	    }

	 
	 /**
		* <Method returns the car at a certain index>
		* 
		* CSC 1351 Programming Project No 1
		* Section <002>
		* 
		* @author <Olivia Womble>
		* @since <05.17.2024>
		*/
	 
	    public Car get(int index) {
	        if (index < 0 || index >= numObjects) {
	            throw new IndexOutOfBoundsException("Index is out of bounds");
	        }
	        return oList[index]; // Return the element at a certain index
	    }

		 /**
			* <Method checks if the list is empty>
			* 
			* CSC 1351 Programming Project No 1
			* Section <002>
			* 
			* @author <Olivia Womble>
			* @since <05.17.2024>
			*/
	    public boolean isEmpty() {
	        return numObjects == 0; 
	    }

	    
		 /**
			* <Method removes the car at a certain index>
			* 
			* CSC 1351 Programming Project No 1
			* Section <002>
			* 
			* @author <Olivia Womble>
			* @since <05.17.2024>
			*/
	    public void remove(int index) {
	        if (index < 0 || index >= numObjects) {
	            throw new IndexOutOfBoundsException("Index is out of bounds");
	        }
	        for (int i = index; i < numObjects - 1; i++) {
	            oList[i] = oList[i + 1];
	        }
	        numObjects--; //decreases the number of objects by 1
	    }
	    
	    
		 /**
			* <Method resets the parameters so that the next object is the first in the list>
			* 
			* CSC 1351 Programming Project No 1
			* Section <002>
			* 
			* @author <Olivia Womble>
			* @since <05.17.2024>
			*/
	    public void reset() {
	        e = 0; 
	    }

	    
		 /**
			* <Method returns the next car and then increases the parameters>
			* 
			* CSC 1351 Programming Project No 1
			* Section <002>
			* 
			* @author <Olivia Womble>
			* @since <05.17.2024>
			*/
	    
	    public Car next() {
	        if (e >= numObjects) {
	            throw new IndexOutOfBoundsException("No more elements in the list");
	        }
	        return oList[e++]; // Increase by 1
	    }

	    	/**
	    	 *<Method checks if there are more objects>
	    	 *	 
	    	 * CSC 1351 Programming Project No 1
	    	 *Section <002>
	    	 * 
	    	 * @author <Olivia Womble>
	    	 * @since <05.17.2024>
			*/
	    public boolean hasNext() {
	        return e < numObjects; 
	    }

		 /**
			* <Method removes the last element returned>
			* 
			* CSC 1351 Programming Project No 1
			* Section <002>
			* 
			* @author <Olivia Womble>
			* @since <05.17.2024>
			*/
	    public void remove() {
	        if (e == 0) {
	            throw new IllegalStateException("next() has not been called yet");
	        }
	        for (int i = e - 1; i < numObjects - 1; i++) {
	            oList[i] = oList[i + 1];
	        }
	        numObjects--; // Decrase by 1
	    }
	}