import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.PrintWriter;



/**
* < Organizing a list of cars>
* 
* CSC 1351 Programming Project No <2>
* 
* Section <002>
* 
* @author <Olivis Womble>
* @since <03.17.2024>
* 
 */
public class Prog01_aOrderedList {
	/**
	    * The main method of this project.
	    * 
	    * CSC 1351 Programming Project No <i1>
	    * Section <002>
	    * 
	    * @author <Olivia Womble>
	    * @since <i03.17.2024>
	    *
	    */

    public static void main(String[] args) throws FileNotFoundException {
        aOrderedList<Car> carList = new aOrderedList<>();// Initializing cars ordered list.
        PrintWriter writer = null;

        
        Car Car1 = new Car("Tesla", 2023, 50000);
        Car Car2 = new Car("Honda", 2003, 3000);
        Car Car3 = new Car("Mercedes", 2015, 25500);

        try {
            Scanner scanner = getInputFile("Please enter your file name\n");// Getting the users input file.
            while (scanner.hasNextLine()) { // reads each line in the users input file.
                String line = scanner.nextLine();
                String[] operation = line.split(",");
                if (operation.length >= 4) { // Make sure there is enough information in the array
                    if (operation[0].equals("A")) { // Adding Cars operation
                        String make = operation[1];
                        try {
                            int year = Integer.parseInt(operation[2]);
                            int price = Integer.parseInt(operation[3]);
                            Car newCar = new Car(make, year, price);
                            carList.add(newCar);
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid format for year or price: " + line);
                        }
                    } else if (operation[0].equals("D")) { // Deleting cars operation
                          if (operation.length >= 2) { // Making sure there's something to delete.
                            try {
                                int index = Integer.parseInt(operation[1]);
                                carList.remove(index);
                            } catch (NumberFormatException e) {
                                System.out.println("Invalid format for index: " + line);
                            }
                        } else {
                            System.out.println("Invalid format for delete operation: " + line);
                        }
                    } else {
                        System.out.println("Unknown operation: " + operation[0]);
                    }
                } else {
                    System.out.print(" ");
                }
            
            }
         
            // Outputting what's in the array.
            System.out.println("Number of cars: " + carList.size());
            for (int i = 0; i < carList.size(); i++) {
                Car car = carList.get(i);
                System.out.println("Make: " + car.getMake());
                System.out.println("Year: " + car.getYear());
                System.out.println("Price: $" + car.getPrice());
                System.out.println();
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
            throw e;
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    
        try {
            Scanner scanner = getInputFile("\n"); // Getting input from the user
            ArrayList<Car> Cars = new ArrayList<>();

            Cars.add(new Car("Tesla", 2023, 45000));
            Cars.add(new Car("Mercedes", 2015, 25500));
            Cars.add(new Car("Honda", 2003, 3000));

            while (scanner.hasNextLine()) { // Reading each line in the users file
                String line = scanner.nextLine();
                String[] carInfo = line.split(",");
                String make = carInfo[0];
                int year = Integer.parseInt(carInfo[1]);
                int price = Integer.parseInt(carInfo[2]);
                Cars.add(new Car(make, year, price));
                int index = Integer.parseInt(carInfo[1]);
                Cars.remove(index);
            }

            scanner.close();

            Collections.sort(Cars); // Sorting the cars
            for (Car car : Cars) {
                printCarInfo(car); // Printing information of the cars
            }

            writer = getOutputFile("Please enter the name for the output file: "); // Getting OutPut file from the User.

            for (Car car : Cars) {
                writer.println(car.toString()); // writing each cars information to the file
            }

        } catch (FileNotFoundException e) {
            System.out.println("File not found");
            throw e;
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
    }
    
/**
    **
    * <Method to get the user to enter a filename and then returns an object for the file.>
    * 
    * CSC 1351 Programming Project No <1>
    * Section <002>
    * 
    * @author <Olivia Womble>
    * @since <03.17.2024>
    *
    */
    public static Scanner getInputFile(String userPrompt) throws FileNotFoundException { 
        Scanner scanner = new Scanner(System.in);
        String filename;
        boolean validFile = false;

        do {
            System.out.print(userPrompt);
            filename = scanner.nextLine();

           //Makes sure users file is valid.
            File file = new File(filename); 
            if (file.exists()) {
                validFile = true;
            } else {
                System.out.println("File not found ");
                System.out.print("Do you want to try again? (Y/N):\n ");
                String filename1 = scanner.nextLine().toLowerCase();
                if (!filename1.equals("y")) {
                    throw new FileNotFoundException("File not found.");
                }
            }
        } while (!validFile);

        return new Scanner(new File(filename));
    }
    /**
     * <Method to get the user to enter an output filename and then returns a PrintWriter object.>
     * 
     * CSC 1351 Programming Project No <1>
     * Section <002>
     * 
     * @author <Olivia Womble>
     * @since <03.17.2024>
     *
     */
    public static PrintWriter getOutputFile(String userPrompt) throws FileNotFoundException {
        Scanner scanner = new Scanner(System.in);
        PrintWriter writer = null;
        boolean validFile = false;

        do {
            System.out.print(userPrompt);
            String filename = scanner.nextLine();

            // Makes sure file exists.
            File file = new File(filename);
            if (!file.exists()) {
                try {
                    writer = new PrintWriter(file);
                    validFile = true;
                } catch (FileNotFoundException e) {
                    System.out.println("Error ");
                }
            } else {
                System.out.println("File already exists. Please enter a different filename.");
            }
        } while (!validFile);

        return writer;
    }
    /**
     * <Method prints the car information>
     * CSC 1351 Programming Project No <1>
     * Section <002>
     * 
     * @author <Olivia Womble>
     * @since <03.17.2024>
     *
     */
    static void printCarInfo(Car car) {
        System.out.println("Make: " + car.getMake() + ", Year: " + car.getYear() + ", Price: " + car.getPrice());
    }

    //giving the car the variables make, year, and price.
    static class Car implements Comparable<Car> {
        private String make;
        private int year;
        private int price;
        
     // initializing car make, year, and price.
        public Car(String Make, int Year, int Price) {
            this.make = Make;
            this.year = Year;
            this.price = Price;
        }

        /**
         * <Method gets the cars make>
         * CSC 1351 Programming Project No <1>
         * Section <002>
         * 
         * @author <Olivia Womble>
         * @since <03.17.2024>
         *
         */
        public String getMake() {
            return make;
        }

        /**
         * <Method gets the cars year>
         * CSC 1351 Programming Project No <1>
         * Section <002>
         * 
         * @author <Olivia Womble>
         * @since <03.17.2024>
         *
         */
        public int getYear() {
            return year;
        }
        
        /**
         * <Method gets the cars price>
         * CSC 1351 Programming Project No <1>
         * Section <002>
         * 
         * @author <Olivia Womble>
         * @since <03.17.2024>
         *
         */
        public int getPrice() {
            return price;
        }
        /**
         * <Method compares cars based on price>
         * CSC 1351 Programming Project No <1>
         * Section <002>
         * 
         * @author <Olivia Womble>
         * @since <03.17.2024>
         *
         */
        @Override
        public int compareTo(Car other) {
            if (Integer.compare(price, other.price) != 0)
                return Integer.compare(price, other.price);
            else
                return Integer.compare(year, other.year);
        }
        /**
         * <Method returns the Car variable in the form of a string>
         * CSC 1351 Programming Project No <1>
         * Section <002>
         * 
         * @author <Olivia Womble>
         * @since <03.17.2024>
         *
         */
        @Override
        public String toString() {
            return "Make: " + make + ", Year: " + year + ", Price: " + price;
        }
    }
}

